<script lang="ts">
	import { getDefaultIconSet, getUserSettings } from "@/lib/services/userSettings.svelte.js";
	import { getConfig } from "@/lib/services/config/config";
	import MenuGeneric from "@/components/menus/MenuGeneric.svelte";
	import * as m from "@/lib/paraglide/messages";
	import RadioGroup from "@/components/ui/input/selectgroup/RadioGroup.svelte";
	import { onIconChange } from "@/lib/services/settings";
	import { getIconForMap } from "@/lib/services/uicons.svelte";
	import SelectGroupItem from "@/components/ui/input/selectgroup/SelectGroupItem.svelte";
	import { type MapData, MapObjectType } from "@/lib/mapObjects/mapObjectTypes";

	let {
		title,
		type,
		getIconParams = {}
	}: {
		title: string;
		type: MapObjectType;
		getIconParams?: Partial<MapData>;
	} = $props();

	function getUiconSets(type: MapObjectType) {
		const allSets = getConfig().uiconSets.filter((s) => s[type]);
		const defaultSetId = getDefaultIconSet(type);
		const index = allSets.findIndex((s) => s.id === defaultSetId.id);
		if (index > 0) {
			const [defaultSet] = allSets.splice(index, 1);
			allSets.unshift(defaultSet);
		}
		return allSets.map((s) => {
			return {
				value: s.id,
				label:
					s.id === defaultSetId.id
						? m.default_()
						: ((typeof s[type] === "object" && s[type] !== null
								? (s[type] as { name?: string }).name
								: undefined) ?? s.name)
			};
		});
	}
</script>

{#if getUiconSets(type).length > 1}
	<MenuGeneric {title}>
		<RadioGroup
			value={(getUserSettings().uiconSet as Record<string, { id: string }>)[type].id}
			onValueChange={(value) => onIconChange(value, type)}
		>
			{#each getUiconSets(type) as iconSet (iconSet.value)}
				<SelectGroupItem class="p-4" value={iconSet.value}>
					<img
						class="w-5"
						src={getIconForMap({ type, ...getIconParams } as Parameters<typeof getIconForMap>[0], {
							iconSet: iconSet.value
						})}
						alt="{title} (Style: {iconSet.label})"
					/>
					{iconSet.label}
				</SelectGroupItem>
			{/each}
		</RadioGroup>
	</MenuGeneric>
{/if}
