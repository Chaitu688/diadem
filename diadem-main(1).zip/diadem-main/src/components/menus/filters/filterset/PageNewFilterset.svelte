<script lang="ts">
	import Button from "@/components/ui/input/Button.svelte";
	import { fly } from "svelte/transition";
	import { CirclePlus } from "@lucide/svelte";
	import {
		filtersetPageNew,
		filtersetPageSelect,
		getFiltersetPageTransition
	} from "@/lib/features/filters/filtersetPages.svelte.js";
	import { setCurrentSelectedFilterset } from "@/lib/features/filters/filtersetPageData.svelte.js";
	import { filterTitle } from "@/lib/features/filters/filtersetUtils.svelte";
	import FiltersetIcon from "@/lib/features/filters/FiltersetIcon.svelte";
	import Separator from "@/components/ui/Separator.svelte";
	import { getPremadeFiltersets } from "@/lib/features/filters/premadeFiltersets";
	import type { FilterCategory } from "@/lib/features/filters/filters";
	import type { AnyFilterset, FiltersetPokemon } from "@/lib/features/filters/filtersets";
	import { pokemonFiltersetRequiredFeature } from "@/lib/features/filters/filterUtilsPokemon";
	import { hasFeatureAnywhere } from "@/lib/services/user/checkPerm";
	import { getUserDetails } from "@/lib/services/user/userDetails.svelte";
	import { Features } from "@/lib/utils/features";
	import { getId } from "@/lib/utils/uuid";
	import { m } from "@/lib/paraglide/messages";

	let {
		majorCategory,
		subCategory = undefined
	}: {
		majorCategory: FilterCategory;
		subCategory?: FilterCategory;
	} = $props();

	function isPremadePermitted(filterset: AnyFilterset): boolean {
		if (majorCategory !== "pokemon" && subCategory !== "pokemon") return true;

		const required = pokemonFiltersetRequiredFeature(filterset as FiltersetPokemon);
		if (required === Features.POKEMON) return true;
		return hasFeatureAnywhere(getUserDetails().permissions, required);
	}

	let allPremades = $derived(
		getPremadeFiltersets(majorCategory) ??
			(subCategory ? getPremadeFiltersets(subCategory) : []) ??
			[]
	);
	let premades = $derived(allPremades.filter(isPremadePermitted));
</script>

<div in:fly={getFiltersetPageTransition().in} out:fly={getFiltersetPageTransition().out}>
	<Button variant="secondary" size="lg" class="w-full" onclick={filtersetPageNew}>
		<CirclePlus size="18" />
		<span>
			{m.create_new()}
		</span>
	</Button>

	<Separator class="my-3" text={m.or_select_suggested_filter()} />

	<div class="-mx-4 px-4">
		<div class="flex flex-col gap-1">
			{#each premades as filterset (filterset.id)}
				<Button
					class="w-full flex gap-2 items-center justify-start rounded-md py-2 h-12 m-0! pl-4 pr-2"
					size=""
					variant="outline"
					onclick={() => {
						filterset.id = getId();
						setCurrentSelectedFilterset(majorCategory, subCategory, filterset, false);
						filtersetPageSelect();
					}}
				>
					<FiltersetIcon {filterset} size={5} />
					<span>{filterTitle(filterset)}</span>
				</Button>
			{/each}
		</div>
	</div>
</div>
