<script module lang="ts">
	const sessionExpandedState: Record<string, boolean> = {};
</script>

<script lang="ts" generics="ParentCategory extends keyof UserSettings['filters']">
	import Card from "@/components/ui/Card.svelte";
	import { ChevronDown, ChevronUp, Eye, EyeOff, FunnelX, Plus } from "@lucide/svelte";
	import MenuGeneric from "@/components/menus/MenuGeneric.svelte";
	import Button from "@/components/ui/input/Button.svelte";
	import FilterControl from "@/components/menus/filters/FilterControl.svelte";

	import { untrack } from "svelte";
	import { slide } from "svelte/transition";
	import { hasAnyFeatureAnywhere, hasFeatureAnywhere } from "@/lib/services/user/checkPerm";
	import { getUserDetails } from "@/lib/services/user/userDetails.svelte";
	import type { AnyFilter, FilterCategory } from "@/lib/features/filters/filters";
	import Switch from "@/components/ui/input/Switch.svelte";
	import { getIconPokemon } from "@/lib/services/uicons.svelte";
	import {
		getUserSettings,
		updateUserSettings,
		type UserSettings
	} from "@/lib/services/userSettings.svelte";
	import { updateAllMapObjects } from "@/lib/mapObjects/updateMapObject";
	import { deleteAllFeaturesOfType } from "@/lib/map/featuresGen.svelte";
	import type { ModalType } from "@/lib/ui/modal.svelte";
	import { MapObjectType } from "@/lib/mapObjects/mapObjectTypes";

	import type { FeaturesKey } from "@/lib/utils/features";

	let {
		requiredPermission,
		title,
		category,
		mapObject,
		filterModal = undefined,
		isFilterable = true,
		subCategories = []
	}: {
		requiredPermission: FeaturesKey | FeaturesKey[];
		title: string;
		category: ParentCategory;
		mapObject: MapObjectType;
		filterModal?: ModalType | undefined;
		isFilterable?: boolean;
		subCategories?: {
			title: string;
			category: FilterCategory;
			requiredPermission: FeaturesKey;
			filterModal?: ModalType;
			filterable?: boolean;
		}[];
	} = $props();

	const primaryFeatures = $derived(
		Array.isArray(requiredPermission) ? requiredPermission : [requiredPermission]
	);
	const sectionFeatures = $derived([
		...primaryFeatures,
		...subCategories.map((subcategory) => subcategory.requiredPermission)
	]);
	const hasPrimaryPermission = $derived(
		hasAnyFeatureAnywhere(getUserDetails().permissions, primaryFeatures)
	);

	let subcategoriesExpanded: boolean = $state(
		untrack(() => sessionExpandedState[category as string] ?? false)
	);

	$effect(() => {
		sessionExpandedState[category as string] = subcategoriesExpanded;
	});

	function onEnabledChange(_: FilterCategory, value: boolean) {
		const filter: AnyFilter = getUserSettings().filters[category];
		filter.enabled = value;

		subCategories.forEach((subcategory) => {
			(getUserSettings().filters[category] as unknown as Record<string, AnyFilter>)[
				subcategory.category
			].enabled = value;
		});

		if (
			mapObject === MapObjectType.POKESTOP ||
			mapObject === MapObjectType.GYM ||
			mapObject === MapObjectType.ROUTE
		) {
			deleteAllFeaturesOfType(MapObjectType.ROUTE);
		}

		updateUserSettings();
		updateAllMapObjects().then();
	}

	function onSubEnabledChange(thisCategory: FilterCategory, value: boolean) {
		(getUserSettings().filters[category] as unknown as Record<string, AnyFilter>)[
			thisCategory
		].enabled = value;

		if (
			value ||
			!Object.values(getUserSettings().filters[category]).find((subcategory) => subcategory.enabled)
		) {
			getUserSettings().filters[category].enabled = value;
		}

		deleteAllFeaturesOfType(mapObject);
		if (
			mapObject === MapObjectType.POKESTOP ||
			mapObject === MapObjectType.GYM ||
			mapObject === MapObjectType.ROUTE
		) {
			deleteAllFeaturesOfType(MapObjectType.ROUTE);
		}

		updateUserSettings();
		updateAllMapObjects().then();
	}
</script>

{#if hasAnyFeatureAnywhere(getUserDetails().permissions, sectionFeatures)}
	<Card class="py-1 px-2">
		{#if hasPrimaryPermission}
			<FilterControl
				{title}
				{isFilterable}
				{filterModal}
				{mapObject}
				majorCategory={category}
				{onEnabledChange}
				isExpandable={subCategories.length > 0}
				collapsibleByFiltersets={subCategories.length === 0}
				filter={getUserSettings().filters[category]}
				bind:expanded={subcategoriesExpanded}
			/>
		{/if}

		{#if subCategories.length > 0}
			{#if subcategoriesExpanded || !hasPrimaryPermission}
				<div class="mb-2" transition:slide={{ duration: 80 }}>
					{#each subCategories as subcategory (subcategory.category)}
						{#if hasFeatureAnywhere(getUserDetails().permissions, subcategory.requiredPermission)}
							<FilterControl
								{mapObject}
								title={subcategory.title}
								majorCategory={category}
								subCategory={subcategory.category}
								filterModal={subcategory.filterModal}
								isFilterable={subcategory.filterable ?? true}
								onEnabledChange={onSubEnabledChange}
								filter={(
									getUserSettings().filters[category] as unknown as Record<string, AnyFilter>
								)[subcategory.category]}
							/>
						{/if}
					{/each}
				</div>
			{/if}
		{/if}
	</Card>
{/if}
