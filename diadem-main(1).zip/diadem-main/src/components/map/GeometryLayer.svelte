<script lang="ts">
	import { FillLayer, GeoJSON, LineLayer } from "svelte-maplibre";
	import type { FeatureCollection, GeoJSON as GeoJsonType } from "geojson";
	import { CoverageMapLayerId, type MapSourceId, updateMapGeojsonSource } from "@/lib/map/layers";
	import { getUserSettings } from "@/lib/services/userSettings.svelte";
	import { getMap, getMapStyleVersion } from "@/lib/map/map.svelte";
	import type * as maplibre from "maplibre-gl";
	import { tick } from "svelte";

	let {
		id,
		data = undefined,
		reactive = true,
		show = true,
		fillId = undefined,
		strokeId = undefined,
		map = undefined,
		hoverCursor = undefined,
		fillOpacity = 0.5
	}: {
		id: MapSourceId;
		data?: FeatureCollection;
		reactive?: Readonly<boolean>;
		show?: boolean | (() => boolean);
		fillId?: any;
		strokeId?: any;
		map?: maplibre.Map;
		hoverCursor?: string;
		fillOpacity?: number;
	} = $props();

	let lastWasEmpty = true;

	// svelte-ignore state_referenced_locally values are never updated
	const makeEffect = reactive && data;

	if (makeEffect) {
		$effect(() => {
			if (!map) map = getMap();
			if (!map) return;

			getMapStyleVersion();
			if (data.features.length === 0 && lastWasEmpty) return;

			lastWasEmpty = data.features.length === 0;
			updateMapGeojsonSource(map, id, data);
		});
	}
</script>

<GeoJSON
	{id}
	data={data ?? {
		type: "FeatureCollection",
		features: []
	}}
>
	{#if typeof show === "function" ? show() : show}
		<FillLayer
			id={fillId}
			{hoverCursor}
			filter={["match", ["geometry-type"], ["Polygon", "MultiPolygon"], true, false]}
			paint={{
				"fill-color": ["get", "fillColor"],
				"fill-opacity": fillOpacity
			}}
		/>
		<LineLayer
			id={strokeId}
			layout={{ "line-cap": "round", "line-join": "round" }}
			paint={{
				"line-color": ["get", "strokeColor"],
				"line-width": ["match", ["geometry-type"], ["Polygon", "MultiPolygon"], 2, 7]
			}}
		/>
	{/if}
</GeoJSON>
