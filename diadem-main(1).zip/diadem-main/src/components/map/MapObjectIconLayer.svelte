<script lang="ts">
	import { SymbolLayer } from "svelte-maplibre";
	import type { ExpressionSpecification } from "maplibre-gl";
	import { getUserSettings } from "@/lib/services/userSettings.svelte";

	let {
		id,
		filter,
		hoverCursor = undefined,
		eventsIfTopMost = false,
		interactive = true
	}: {
		id: string;
		filter: ExpressionSpecification;
		hoverCursor?: string;
		eventsIfTopMost?: boolean;
		interactive?: boolean;
	} = $props();
</script>

<SymbolLayer
	{id}
	{filter}
	{hoverCursor}
	{eventsIfTopMost}
	{interactive}
	layout={{
		"icon-image": [
			"case",
			["get", "dimmed"],
			["concat", ["get", "imageId"], "/dimmed"],
			["get", "imageId"]
		],
		"icon-overlap": "always",
		"icon-size": [
			"*",
			["get", "imageSize"],
			["get", "selectedScale"],
			getUserSettings().mapIconSize
		],
		"icon-allow-overlap": true,
		"icon-offset": ["coalesce", ["get", "imageOffset"], ["literal", [0, 0]]],
		"icon-rotate": ["coalesce", ["get", "imageRotation"], 0],
		"text-field": ["coalesce", ["get", "textLabel"], ""],
		"text-anchor": "top",
		"text-offset": [0, 1],
		"text-size": 11,
		"text-allow-overlap": true,
		"text-font": ["IBM Plex Sans", "Open Sans", "Noto Sans", "Arial Unicode MS Bold", "sans-serif"]
	}}
	paint={{
		"icon-opacity": ["case", ["coalesce", ["get", "dimmed"], false], 0.4, 1],
		"text-color": "#fafafa",
		"text-opacity": ["case", ["coalesce", ["get", "dimmed"], false], 0.45, 1],
		"text-halo-color": "#09090b",
		"text-halo-width": 1.5
	}}
/>
