<script lang="ts">
	import { CircleLayer, FillLayer, GeoJSON, LineLayer } from "svelte-maplibre";
	import { getUserSettings, updateUserSettings } from "@/lib/services/userSettings.svelte.js";
	import { onDestroy, onMount, tick } from "svelte";
	import {
		getDirectLinkFeature,
		getDirectLinkObject,
		openMapObject
	} from "@/lib/features/directLinks.svelte.js";
	import { clickMapHandler, openLocationPopup, updateCurrentPath } from "@/lib/mapObjects/interact";
	import { updateAllMapObjects } from "@/lib/mapObjects/updateMapObject";
	import * as m from "@/lib/paraglide/messages";
	import {
		clearUpdateMapObjectsInterval,
		resetUpdateMapObjectsInterval
	} from "@/lib/map/mapObjectsInterval";
	import { getMap, setMap } from "@/lib/map/map.svelte";
	import { clearPressTimer, onLocationContext } from "$lib/map/locationEvents";
	import { clearLoadMapObjectsInterval } from "@/lib/map/loadMapObjects";
	import {
		onMapDragStart,
		onMapMoveEnd,
		onMapMoveStart,
		onTouchStart,
		onWindowFocus
	} from "@/lib/map/events";
	import type * as maplibre from "maplibre-gl";
	import GeometryLayer from "@/components/map/GeometryLayer.svelte";
	import WeatherLayer from "@/components/map/WeatherLayer.svelte";
	import DebugMenu from "@/components/map/DebugMenu.svelte";
	import { hasLoadedFeature, LoadedFeature } from "@/lib/services/initialLoad.svelte.js";
	import { openToast } from "@/lib/ui/toasts.svelte.js";
	import MarkerCurrentLocation from "@/components/map/MarkerCurrentLocation.svelte";
	import LocationMapOverlay from "@/components/map/LocationMapOverlay.svelte";
	import { getCurrentScoutData } from "@/lib/features/scout.svelte.js";
	import {
		getCurrentSelectedFiltersetIsShared,
		openFiltersetModal
	} from "@/lib/features/filters/filtersetPageData.svelte";
	import { filtersetPageReset } from "@/lib/features/filters/filtersetPages.svelte";
	import { getOpenedMenu, Menu, openMenu } from "@/lib/ui/menus.svelte";
	import { MapObjectLayerId, MapSourceId } from "@/lib/map/layers";
	import { mAny } from "@/lib/utils/anyMessage";
	import MarkerSearchedLocation from "@/components/map/MarkerSearchedLocation.svelte";
	import MapObjectIconLayer from "@/components/map/MapObjectIconLayer.svelte";
	import { FeatureTypes } from "@/lib/map/render/featureTypes";
	import MapCommon from "@/components/map/MapCommon.svelte";
	import {
		clearMapPositionUrlParams,
		getInitialMapPositionMain,
		getMapPositionFromUrlParams
	} from "$lib/map/mapPositionParams.svelte";
	import { Coords } from "@/lib/utils/coordinates";
	import TimerLayer from "@/components/map/TimerLayer.svelte";
	import LayerSearchedGeometry from "@/components/map/LayerSearchedGeometry.svelte";
	import { getFeatureJump } from "$lib/utils/geo";
	import { jumpTo } from "$lib/map/utils";
	import { setSearchedGeometry } from "$lib/services/search.svelte";
	import MapAttribution from "@/components/map/MapAttribution.svelte";
	import { isUiLeft } from "$lib/utils/device";

	let {
		map = $bindable()
	}: {
		map?: maplibre.Map | undefined;
	} = $props();

	const mapPosition = getInitialMapPositionMain();
	const [initialLocation, initialLocationZoom] = getMapPositionFromUrlParams();

	async function onMapLoad(map: maplibre.Map) {
		setMap(map);

		map.on("moveend", onMapMoveEnd);
		map.on("contextmenu", onLocationContext);
		map.on("touchstart", onTouchStart);
		map.on("touchend", clearPressTimer);
		map.on("touchmove", clearPressTimer);
		map.on("touchcancel", clearPressTimer);
		map.on("dragstart", onMapDragStart);
		map.on("movestart", onMapMoveStart);

		// tick so feature handler registers first
		tick().then(() => map?.on("click", clickMapHandler));
	}

	// update initial map objects only once every required part has been loaded
	let isInitUpdatedMapObjects = false;
	$effect(() => {
		const map = getMap();
		if (
			!isInitUpdatedMapObjects &&
			map &&
			hasLoadedFeature(
				LoadedFeature.REMOTE_LOCALE,
				LoadedFeature.MASTER_FILE,
				LoadedFeature.ICON_SETS,
				LoadedFeature.USER_DETAILS,
				LoadedFeature.SERVER_USER_SETTINGS
			)
		) {
			const directLinkFeature = getDirectLinkFeature();
			if (directLinkFeature) {
				const params = getFeatureJump(directLinkFeature, true);
				jumpTo(params.coords, params.zoom);
				setSearchedGeometry(directLinkFeature.geometry);
			}

			const directLinkData = getDirectLinkObject();
			if (directLinkData) {
				if (directLinkData.id) {
					openMapObject(directLinkData);
				} else if ("noPermission" in directLinkData && directLinkData.noPermission) {
					openToast(
						m.direct_link_no_permission({
							type: mAny("pogo_" + directLinkData.type)
						}),
						5000
					);
				} else {
					openToast(
						m.direct_link_not_found({
							type: mAny("pogo_" + directLinkData.type)
						}),
						5000
					);
				}
			}

			if (initialLocation && !directLinkFeature && !directLinkData) {
				openLocationPopup(initialLocation, { replace: true, zoom: initialLocationZoom });
			}

			if (getCurrentSelectedFiltersetIsShared()) {
				openMenu(Menu.FILTERS);
				filtersetPageReset();
				tick().then(openFiltersetModal);
			}

			isInitUpdatedMapObjects = true;
			updateAllMapObjects(false)
				.then(() => {
					resetUpdateMapObjectsInterval();
				})
				.catch((e) => console.error(e));
		}
	});

	onMount(async () => {
		await tick();
		isInitUpdatedMapObjects = false;
		setMap(undefined);
		updateCurrentPath();
		if (!initialLocation) clearMapPositionUrlParams();
	});

	onDestroy(() => {
		clearUpdateMapObjectsInterval();
		clearLoadMapObjectsInterval();
		setMap(undefined);
	});
</script>

<svelte:window onfocus={onWindowFocus} onblur={clearUpdateMapObjectsInterval} />

<DebugMenu />

<MapCommon
	bind:map
	onload={onMapLoad}
	initialCenter={Coords.infer(mapPosition.center)}
	initialZoom={mapPosition.zoom}
	showAttribution={false}
>
	<MapAttribution {map} class={isUiLeft() ? "left-2 right-auto" : "right-2"} />

	<WeatherLayer />
	<GeometryLayer
		show={() => getOpenedMenu() === Menu.SCOUT}
		id={MapSourceId.SCOUT_BIG_POINTS}
		data={getCurrentScoutData().bigPoints}
	/>
	<GeometryLayer
		show={() => getOpenedMenu() === Menu.SCOUT}
		id={MapSourceId.SCOUT_SMALL_POINTS}
		data={getCurrentScoutData().smallPoints}
	/>

	<LocationMapOverlay />
	<LayerSearchedGeometry />

	<GeoJSON
		id={MapSourceId.MAP_OBJECTS}
		data={{
			type: "FeatureCollection",
			features: []
		}}
	>
		<FillLayer
			id={MapObjectLayerId.RADIUS_FILL}
			filter={["==", ["get", "isActionRadius"], true]}
			paint={{
				"fill-color": ["coalesce", ["get", "fillColor"], "transparent"]
			}}
		/>
		<LineLayer
			id={MapObjectLayerId.RADIUS_STROKE}
			filter={["==", ["get", "isActionRadius"], true]}
			layout={{ "line-cap": "round", "line-join": "round" }}
			paint={{ "line-color": ["coalesce", ["get", "strokeColor"], "transparent"], "line-width": 2 }}
		/>
		<FillLayer
			id={MapObjectLayerId.POLYGON_FILL}
			filter={["==", ["get", "type"], FeatureTypes.POLYGON]}
			paint={{
				"fill-color": [
					"case",
					["coalesce", ["get", "isSelected"], false],
					["coalesce", ["get", "selectedFill"], "transparent"],
					["coalesce", ["get", "fillColor"], "transparent"]
				]
			}}
			hoverCursor="pointer"
		/>
		<LineLayer
			id={MapObjectLayerId.POLYGON_STROKE}
			filter={["==", ["get", "type"], FeatureTypes.POLYGON]}
			layout={{ "line-cap": "round", "line-join": "round" }}
			paint={{ "line-color": ["coalesce", ["get", "strokeColor"], "transparent"], "line-width": 1 }}
			hoverCursor="pointer"
		/>
		<LineLayer
			id={MapObjectLayerId.ROUTE_LINES}
			filter={[
				"all",
				["==", ["get", "type"], FeatureTypes.LINE],
				["==", ["get", "isVisible"], true],
				["==", ["get", "isHighlighted"], false]
			]}
			layout={{ "line-cap": "round", "line-join": "round" }}
			paint={{
				"line-color": ["coalesce", ["get", "strokeColor"], "#6366f1"],
				"line-opacity": ["case", ["coalesce", ["get", "isDimmed"], false], 0.2, 0.4],
				"line-width": 4
			}}
			hoverCursor="pointer"
			eventsIfTopMost={true}
		/>
		<LineLayer
			id={MapObjectLayerId.ROUTE_LINES_HIGHLIGHTED}
			filter={[
				"all",
				["==", ["get", "type"], FeatureTypes.LINE],
				["==", ["get", "isVisible"], true],
				["==", ["get", "isHighlighted"], true]
			]}
			layout={{ "line-cap": "round", "line-join": "round" }}
			paint={{
				"line-color": ["coalesce", ["get", "strokeColor"], "#6366f1"],
				"line-opacity": 1,
				"line-width": 7
			}}
			hoverCursor="pointer"
			eventsIfTopMost={true}
		/>
		<CircleLayer
			id={MapObjectLayerId.CIRCLES}
			hoverCursor="pointer"
			filter={["==", ["get", "type"], FeatureTypes.CIRCLE]}
			paint={{
				"circle-radius": [
					"*",
					["get", "radius"],
					["get", "selectedScale"],
					getUserSettings().mapIconSize
				],
				"circle-color": ["coalesce", ["get", "fillColor"], "transparent"],
				"circle-stroke-width": 1,
				"circle-stroke-color": ["coalesce", ["get", "strokeColor"], "transparent"]
			}}
			eventsIfTopMost={true}
		/>
		<MapObjectIconLayer
			id={MapObjectLayerId.ICONS}
			hoverCursor="pointer"
			filter={["==", ["get", "type"], FeatureTypes.ICON]}
			eventsIfTopMost={true}
		/>
	</GeoJSON>

	<MarkerCurrentLocation showLocationPopup />
	<MarkerSearchedLocation />
	<TimerLayer />
</MapCommon>
