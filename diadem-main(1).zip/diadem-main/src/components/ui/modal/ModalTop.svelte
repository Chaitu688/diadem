<script lang="ts">
	import type { Snippet } from "svelte";
	import { Dialog, type WithoutChild } from "bits-ui";
	import { closeModal, isOpenModal, type ModalType, openModal } from "@/lib/ui/modal.svelte.js";
	import Button from "@/components/ui/input/Button.svelte";
	import Modal from "@/components/ui/modal/Modal.svelte";

	let {
		class: class_ = "",
		modalType,
		children,
		onopenchange = undefined
	}: {
		class?: string;
		modalType: ModalType;
		children?: Snippet;
		onopenchange?: Dialog.RootProps["onOpenChange"];
	} = $props();
</script>

<Modal
	{modalType}
	{onopenchange}
	class="data-[state=closed]:slide-out-to-top-4! data-[state=open]:slide-in-from-top-4! zoom-in-100! zoom-out-100! top-safe-inset-top! translate-y-0! {class_}"
>
	{@render children?.()}
</Modal>
