<script lang="ts">
	import { onMount } from "svelte";
	import { MapPin, Nut, Search, Spotlight, Squirrel, X } from "@lucide/svelte";
	import * as m from "@/lib/paraglide/messages";
	import { closeSearchModal } from "@/lib/ui/modal.svelte.js";
	import { getActiveSearch } from "@/lib/features/activeSearch.svelte.js";
	import Button from "@/components/ui/input/Button.svelte";
	import ModalTop from "@/components/ui/modal/ModalTop.svelte";
	import {
		type AnySearchEntry,
		getCurrentSearchQuery,
		getCurrentSearchResults,
		getIsSearchingAddress,
		search,
		type SearchOptions,
		setCurrentSearchQuery
	} from "@/lib/services/search.svelte";
	import { isSupportedFeature } from "@/lib/services/supportedFeatures";
	import { getUserSettings } from "@/lib/services/userSettings.svelte";
	import type { FuzzyResult } from "@nozbe/microfuzz";
	import MainSearchResults from "@/components/ui/search/MainSearchResults.svelte";
	import { Command } from "bits-ui";

	let { searchOptions }: { searchOptions: SearchOptions } = $props();

	let input: HTMLInputElement | undefined = $state();

	onMount(() => {
		input?.focus();
	});

	let recentSearches: FuzzyResult<AnySearchEntry>[] = $derived(
		getUserSettings().recentSearches.map((i) => {
			return { item: i, score: 0, matches: [] };
		})
	);

	let results = $derived(getCurrentSearchResults());

	$effect(() => {
		search(getCurrentSearchQuery(), true, searchOptions);
	});
</script>

<ModalTop
	class="w-[calc(100%-1rem)]! max-w-2xl!"
	modalType="search"
	onopenchange={(open) => {
		if (!open && !getActiveSearch()) setCurrentSearchQuery("");
	}}
>
	<Command.Root
		class="rounded-lg bg-card text-card-foreground max-h-[calc(100vh-1rem)] overflow-hidden"
		shouldFilter={false}
	>
		<div class="flex items-center border-b pb-px pr-px pl-2">
			<Search class="mr-2 h-4 w-4 shrink-0 opacity-50" />

			<Command.Input
				bind:value={getCurrentSearchQuery, setCurrentSearchQuery}
				ref={input}
				placeholder={m.search_placeholder()}
				autocomplete="off"
				spellcheck="false"
				type="search"
				class="placeholder:text-muted-foreground flex h-11 w-full rounded-md bg-transparent py-3 pr-2 text-sm outline-hidden disabled:cursor-not-allowed disabled:opacity-50"
			/>

			<Button variant="ghost" size="" class="rounded-md p-2 mr-1" onclick={closeSearchModal}>
				<X size="20" class="opacity-50" />
			</Button>
		</div>

		<Command.List class="overflow-y-auto overflow-x-hidden mx-1 pb-1 max-h-200">
			<Command.Viewport>
				{#if (searchOptions?.showRecents ?? true) && !getCurrentSearchQuery() && recentSearches.length > 0}
					<Command.Group>
						<Command.GroupHeading
							class="text-muted-foreground p-1 px-2 py-1.5 text-xs font-medium self-starts"
						>
							{m.search_recent()}
						</Command.GroupHeading>
						<Command.GroupItems>
							<MainSearchResults results={recentSearches} />
						</Command.GroupItems>
					</Command.Group>
					<!--this sometimes shows up even though there's results. extra check to avoid that-->
				{:else if results.length === 0 && !getIsSearchingAddress()}
					<Command.Empty>
						{#if !searchOptions.textSearchHint && !searchOptions.textNoResults}
							<div
								class="w-full flex gap-4 items-center px-4 pt-3 pb-1 text-muted-foreground text-sm"
							>
								{#if getCurrentSearchQuery()}
									<Nut size="24" class="rotate-24" />
								{:else}
									<Squirrel size="24" />
								{/if}

								<div>
									<p class="font-semibold">
										{#if getCurrentSearchQuery()}
											{m.nothing_found()}
										{:else}
											{m.nothing_to_see_here()}
										{/if}
									</p>
									<p>
										{#if isSupportedFeature("koji") && isSupportedFeature("geocoding")}
											{m.search_hint()}
										{:else if isSupportedFeature("koji")}
											{m.search_hint_no_area()}
										{:else if isSupportedFeature("geocoding")}
											{m.search_hint_no_address()}
										{:else}
											{m.search_hint_no_area_address()}
										{/if}
									</p>
								</div>
							</div>
						{:else}
							<div
								class="pt-1.5 pb-0.5 mt-1 px-2 text-sm text-muted-foreground flex gap-2 items-center"
							>
								<Spotlight class="shrink-0" size="16" />

								{#if getCurrentSearchQuery()}
									{searchOptions.textNoResults}
								{:else}
									{searchOptions.textSearchHint}
								{/if}
							</div>
						{/if}
					</Command.Empty>
				{/if}

				<Command.Group class="mt-1">
					<Command.GroupItems>
						{#if searchOptions.resultSnippet}
							{@render searchOptions.resultSnippet(results)}
						{:else}
							<MainSearchResults {results} />
						{/if}
					</Command.GroupItems>
				</Command.Group>

				{#if getIsSearchingAddress()}
					<div
						class="py-1.5 px-2 text-sm text-muted-foreground flex gap-2 items-center animate-pulse duration-1000"
					>
						<MapPin class="shrink-0" size="16" />

						<span>{m.searching_for_addresses()}</span>
					</div>
				{/if}
			</Command.Viewport>
		</Command.List>
	</Command.Root>
</ModalTop>
