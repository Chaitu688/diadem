<script lang="ts">
	import { fly } from "svelte/transition";
	import { getCurrentSelectedData } from "@/lib/mapObjects/currentSelectedState.svelte";
	import {
		ClientMapObjectType,
		type MapData,
		MapObjectType
	} from "@/lib/mapObjects/mapObjectTypes";
	import PopupBaseDrawer from "@/components/ui/popups/common/PopupBaseDrawer.svelte";
	import { Coords } from "$lib/utils/coordinates";
	import { watch } from "runed";
	import { getPopupPropsPokemon } from "@/components/ui/popups/pokemon/PokemonPopup.svelte";
	import PopupBaseStatic, {
		type MapObjectPopupProps
	} from "@/components/ui/popups/common/PopupBaseStatic.svelte";
	import { getPopupPropsPokestop } from "@/components/ui/popups/pokestop/PokestopPopup.svelte";
	import { getPopupPropsNest } from "@/components/ui/popups/nest/NestPopup.svelte";
	import { getPopupPropsTappable } from "@/components/ui/popups/tappable/TappablePopup.svelte";
	import { getPopupPropsSpawnpoint } from "@/components/ui/popups/spawnpoint/SpawnpointPopup.svelte";
	import { getPopupPropsStation } from "@/components/ui/popups/station/StationPopup.svelte";
	import { getPopupPropsGym } from "@/components/ui/popups/gym/GymPopup.svelte";
	import { getPopupPropsRoute } from "@/components/ui/popups/route/RoutePopup.svelte";
	import { isAllowedTwoSidebars } from "$lib/utils/device";
	import { closeMenu } from "$lib/ui/menus.svelte";
	import { isSearchViewActive } from "$lib/features/activeSearch.svelte";
	import {
		centerRequestedMapObjectIfPopupCovers,
		getPopupVisibilityRequest,
		setPopupOcclusion,
		type PopupVisibilityRequest
	} from "$lib/mapObjects/popupVisibility.svelte";
	import { getPopupPropsLocation } from "@/components/ui/popups/location/LocationPopup.svelte";

	let {
		alwaysExpanded = false
	}: {
		alwaysExpanded?: boolean;
	} = $props();

	const propMap: Partial<Record<MapData["type"], (data: MapData) => MapObjectPopupProps>> = {
		[MapObjectType.POKEMON]: getPopupPropsPokemon,
		[MapObjectType.POKESTOP]: getPopupPropsPokestop,
		[MapObjectType.NEST]: getPopupPropsNest,
		[MapObjectType.TAPPABLE]: getPopupPropsTappable,
		[MapObjectType.SPAWNPOINT]: getPopupPropsSpawnpoint,
		[MapObjectType.GYM]: getPopupPropsGym,
		[MapObjectType.STATION]: getPopupPropsStation,
		[MapObjectType.ROUTE]: getPopupPropsRoute,
		[ClientMapObjectType.LOCATION]: getPopupPropsLocation
	};

	let data = $derived(getCurrentSelectedData());
	let doesDataExist = $derived(Boolean(data && data.type !== MapObjectType.S2_CELL));
	let snapshotData: MapData | undefined = $state(undefined);
	let popupWidth = 0;
	let pendingVisibilityRequest: PopupVisibilityRequest | undefined;

	function checkPopupVisibility() {
		if (!pendingVisibilityRequest || !popupWidth) return;

		const request = pendingVisibilityRequest;
		pendingVisibilityRequest = undefined;
		centerRequestedMapObjectIfPopupCovers(request, { width: popupWidth });
	}

	function updatePopupWidth(width: number | undefined) {
		popupWidth = width ?? 0;
		setPopupOcclusion(popupWidth ? { width: popupWidth } : undefined);
		checkPopupVisibility();
	}

	watch(
		() => getPopupVisibilityRequest(),
		(request) => {
			pendingVisibilityRequest = alwaysExpanded ? request : undefined;
			checkPopupVisibility();
		}
	);

	watch(
		() => data,
		() => {
			if (doesDataExist && data) {
				if (!isAllowedTwoSidebars()) {
					closeMenu();
				}
				snapshotData = $state.snapshot(data);
			} else {
				setPopupOcclusion(undefined);
			}
		}
	);

	let popupData = $derived(data ?? snapshotData);
	let popupProps = $derived(popupData ? propMap[popupData.type]?.(popupData) : undefined);
	let popupCoords = $derived(new Coords(popupData?.lat ?? 0, popupData?.lon ?? 0));
</script>

{#if alwaysExpanded}
	{#if doesDataExist}
		<div
			bind:offsetWidth={null, updatePopupWidth}
			class="h-full min-w-80 max-w-110 basis-110 shrink grow-0"
			transition:fly={{ duration: 130, x: 120 }}
			class:pt-18={isSearchViewActive()}
		>
			<div
				class="z-10 h-full relative overflow-y-auto [scrollbar-gutter:stable_both-edges] rounded-l-xl border border-border bg-card pt-6 pointer-events-auto"
			>
				<PopupBaseStatic
					coords={popupCoords}
					data={popupData}
					props={popupProps}
					onlyShowNavigationButton={false}
				/>
			</div>
		</div>
	{/if}
{:else}
	<PopupBaseDrawer open={doesDataExist} coords={popupCoords} data={popupData} props={popupProps} />
{/if}
