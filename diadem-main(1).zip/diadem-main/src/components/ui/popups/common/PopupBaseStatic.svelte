<script module lang="ts">
	import type { Snippet } from "svelte";
	import type { MapData } from "$lib/mapObjects/mapObjectTypes";
	import { useMetadata } from "$lib/ui/metadata.svelte";

	export type MapObjectPopupProps = {
		type: string;
		title: string;
		image: Snippet<[MapData]>;
		overview?: Snippet<[MapData]>;
		heading?: Snippet<[MapData, Snippet]>;
		headerDetails?: Snippet<[MapData]>;
		titleDetails?: Snippet<[MapData]>;
		main: Snippet<[MapData]>;
	};
</script>

<script lang="ts">
	import { getCurrentSelectedData } from "$lib/mapObjects/currentSelectedState.svelte";
	import * as m from "$lib/paraglide/messages";
	import PopupButtons from "@/components/ui/popups/common/PopupButtons.svelte";
	import {
		backupShareUrl,
		canNativeShare,
		copyToClipboard,
		hasClipboardWrite
	} from "$lib/utils/device";
	import Button from "@/components/ui/input/Button.svelte";
	import { Copy, Navigation, Share2, X } from "@lucide/svelte";
	import { getRootOrigin } from "$lib/native/runtime";
	import { closePopup, getCurrentPath } from "$lib/mapObjects/interact";
	import { getLocale } from "$lib/paraglide/runtime";
	import { getMapsUrl } from "$lib/utils/mapUrl";
	import { Coords } from "$lib/utils/coordinates";
	import { getShareTitle } from "$lib/features/shareTexts";
	import PopupButton from "@/components/ui/popups/common/PopupButton.svelte";

	let {
		coords,
		props,
		data,
		onlyShowNavigationButton
	}: {
		coords: Coords;
		data: MapData | undefined;
		props: MapObjectPopupProps | undefined;
		onlyShowNavigationButton: boolean;
	} = $props();

	useMetadata(() => ({ title: props ? props.title : undefined }));

	function getShareUrl() {
		const path = getCurrentPath({ data });
		return getRootOrigin() + path + (path.includes("?") ? "&" : "?") + "lang=" + getLocale();
	}
</script>

{#snippet headingControls()}
	{#if canNativeShare({ url: getShareUrl() })}
		<Button
			variant="ghost"
			size=""
			class="rounded-full p-2 size-9 bg-accent/50"
			title={m.popup_share()}
			onclick={() => backupShareUrl(getShareUrl())}
		>
			<Share2 class="size-3.5" />
		</Button>
	{:else if hasClipboardWrite()}
		<Button
			variant="ghost"
			size=""
			class="rounded-full p-2 size-9 bg-accent/50"
			title={m.copy_link()}
			onclick={() => copyToClipboard(getShareUrl())}
		>
			<Copy class="size-3.5" />
		</Button>
	{/if}

	<Button
		variant="ghost"
		size=""
		class="rounded-full p-2 size-9 bg-accent/50"
		title={m.close()}
		onclick={() => closePopup()}
	>
		<X class="size-4.5" />
	</Button>
{/snippet}

{#if props && data && props.heading}
	{@render props.heading(data, headingControls)}
{:else}
	<div class="flex gap-3 px-4 pr-24">
		{#if props && data}
			{@render props.image(data)}
			<div class="min-w-0">
				<p class="text-muted-foreground text-sm font-medium">
					{props.type}
				</p>
				<h1 class="flex flex-wrap items-center gap-x-2 break-words text-xl font-semibold">
					<span class="min-w-0 max-w-full">{props.title}</span>
					{#if props.titleDetails}{@render props.titleDetails(data)}{/if}
				</h1>
			</div>
		{/if}

		<div class="absolute right-2 top-2 flex gap-3">
			{@render headingControls()}
		</div>
	</div>
{/if}

{#if props && data && props.headerDetails}
	<div class="px-4 mt-2">{@render props.headerDetails(data)}</div>
{/if}

{#if props && data && props.overview}
	<div class="w-full">
		<div class="overflow-x-auto flex *:shrink-0 gap-2 px-4 has-[*]:mt-4 touch-pan-x">
			{#if props && data}
				{@render props.overview(data)}
			{/if}
		</div>
	</div>
{/if}

<div class="mt-3" data-popup-initial-snap-point-end>
	{#if onlyShowNavigationButton}
		<PopupButton
			class="mx-4 w-full"
			variant="default"
			Icon={Navigation}
			label={m.popup_navigate()}
			tag="a"
			href={getMapsUrl(coords, getShareTitle(getCurrentSelectedData()))}
			target="_blank"
		/>
	{:else if data}
		<PopupButtons lat={coords.lat} lon={coords.lon} {data} />
	{/if}
</div>

<div
	data-popup-body
	class="min-w-0 flex flex-col gap-5 px-4 pt-2 pb-5 overflow-y-auto [&>*]:shrink-0"
>
	{#if props && data}
		{@render props.main(data)}
	{/if}
</div>
