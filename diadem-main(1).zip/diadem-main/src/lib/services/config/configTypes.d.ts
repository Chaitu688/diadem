import type { DefaultFilters } from "@/lib/services/config/defaultFilters";
import { MapObjectType } from "@/lib/mapObjects/mapObjectTypes";

import type { FeaturesKey } from "@/lib/utils/features";

type UiconSetModifiers = {
	default: boolean;
	scale?: number;
	offsetX?: number;
	offsetY?: number;
	name?: string;
	spacing?: number;
};

export type UiconSetModifierType =
	| MapObjectType
	| "quest"
	| "invasion"
	| "max_battle"
	| "raid_pokemon"
	| "raid_pokemon_6"
	| "raid_egg"
	| "raid_egg_6";

export type UiconSet = {
	id: string;
	name: string;
	url: string;
	base: UiconSetModifiers | undefined;
} & {
	[key in UiconSetModifierType]: UiconSetModifiers | boolean | undefined;
};

type General = {
	/** Show the access mini-map sections in object popups. Defaults to true. */
	showAccessMaps?: boolean;
	mapName: string;
	defaultLocale: string;
	customHome: boolean;
	defaultLat?: number;
	defaultLon?: number;
	defaultZoom?: number;
	minZoom?: number;
	maxZoom?: number;
	url?: string;
	image?: string;
	description?: string;
	allowCrawlers?: boolean;
	disallowedPaths?: string[];
	/** Default true. Set to false to exchange JSON instead of MessagePack with the API (less CPU, more bytes). */
	msgpack?: boolean;
};

export type DbCreds = {
	host: string;
	port: number;
	database: string;
	user: string;
	password: string;
};

type Auth = {
	enabled: boolean;
	optional: boolean;
	secret?: string;
	baseUrl?: string;
	discord?: AuthDiscord;
};

type AuthDiscord = {
	clientId: string;
	clientSecret: string;
};

type ClientDiscord = {
	serverLink: string;
	serverId: string;
};

export type Permissions = {
	everyone?: boolean;
	loggedIn?: boolean;
	guildId?: string;
	roleId?: string;
	areas?: string[];
	features?: FeaturesKey[];
};

export type Log = {
	level: string;
	file?: string;
};

export type MapStyle = {
	id: string;
	name: string;
	url: string;
	default?: "dark" | "light";
	theme?: "dark" | "light" | "satellite";
	colors?: "dark" | "light";
	raster?: {
		min: number;
		max: number;
		tileSize: number;
	};
	attribution?: string;
};

type MapPositions = {
	styleLat: number;
	styleLon: number;
	styleZoom: number;
	coverageLat: number;
	coverageLon: number;
	coverageZoom: number;
	scoutLat: number;
	scoutLon: number;
	scoutZoom: number;
	coverageMapLat?: number;
	coverageMapLon?: number;
	coverageMapZoom?: number;
};

type StaticMap = {
	enabled: boolean;
	url: string;
	diademUrl: string;
	style?: string;
};

export type ClientConfig = {
	defaultFilters?: DefaultFilters;
	mapStyles: MapStyle[];
	uiconSets: UiconSet[];
	general: General;
	discord: ClientDiscord;
	mapPositions: MapPositions;
	tools: {
		showToolsMenu: boolean;
		coverageMap: boolean;
		scout: boolean;
	};
};

export type ServerConfig = {
	golbat: {
		url: string;
		auth?: string;
		secret?: string;
		defaultNestName?: string;
		grpc?: string;
		fortApi?: boolean;
	};
	dragonite: {
		// TODO: this should be optional and scout disabled
		url: string;
		secret?: string;
		basicAuth?: string;
	};
	db: DbCreds;
	koji?: {
		url: string;
		secret: string;
		projectName: string;
	};
	nominatim?: {
		url: string;
		basicAuth?: string;
		userAgent?: string;
	};
	pelias?: {
		url: string;
		apiKey?: string;
		basicAuth?: string;
	};
	photon?: {
		url: string;
		basicAuth?: string;
		hasGeometries?: boolean;
	};
	log: Log;
	internalDb: DbCreds;
	auth: Auth;
	permissions?: Permissions[];
	staticMap?: StaticMap;
	limits?: {
		enableRateLimiting?: boolean;
		nonDeltaMultiplier?: number;
		heavyFilterMultiplier?: number;
		heavyFilterRatio?: number;
		captchaOnRateLimit?: boolean;
		captchaReward?: number;
	} & {
		[key in MapObjectType]?: {
			requestLimit?: number;
			rateLimit?: number;
			rateLimitTime?: number;
		};
	};
};

/** Exact public origins; backend credentials and permissions remain shared. */
export type SiteConfig = {
	origin: string;
	client: {
		general?: Partial<General>;
		discord?: Partial<ClientDiscord>;
		mapPositions?: Partial<MapPositions>;
		tools?: Partial<ClientConfig["tools"]>;
		defaultFilters?: DefaultFilters;
	};
};

export type Config = {
	sites?: SiteConfig[];
	server: ServerConfig;
	client: ClientConfig;
};
