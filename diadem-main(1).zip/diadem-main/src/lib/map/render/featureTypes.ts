import { resize } from "@/lib/services/assets";
import type { Feature as GeojsonFeature, LineString, MultiPolygon, Point } from "geojson";

export enum FeatureTypes {
	ICON = 0,
	POLYGON = 1,
	CIRCLE = 2,
	LINE = 3
}

export type MapObjectIconProperties = {
	id: string;
	type: FeatureTypes.ICON;
	imageUrl: string;
	imageId: string;
	imageSize: number;
	normalize?: boolean;
	selectedScale: number;
	dimmed: boolean;
	imageOffset?: [number, number];
	isModifierBadge?: boolean;
	isModifierUnderlay?: boolean;
	imageRotation?: number;
	textLabel?: string;
	textOffset?: number;
	routeEndpointFortId?: string;
	expires: number | null;
};
export type MinMapObjectIconProperties = Omit<
	MapObjectIconProperties,
	"type" | "imageId" | "dimmed"
> & {
	imageId?: string;
	dimmed?: boolean;
};

export type MapObjectPolygonProperties = {
	id: string;
	type: FeatureTypes.POLYGON;
	fillColor: string;
	strokeColor: string;
	selectedFill: string;
	isSelected: boolean;
	isActionRadius?: boolean;
};

export type MapObjectCircleProperties = {
	id: string;
	type: FeatureTypes.CIRCLE;
	radius: number;
	selectedScale: number;
	fillColor: string;
	strokeColor: string;
};

export type MapObjectLineProperties = {
	id: string;
	type: FeatureTypes.LINE;
	strokeColor: string;
	startFortId: string;
	endFortId: string;
	reversible: boolean;
	isVisible: boolean;
	isHighlighted: boolean;
	isDimmed: boolean;
};

export type MapObjectIconFeature = GeojsonFeature<Point, MapObjectIconProperties>;
export type MapObjectPolygonFeature = GeojsonFeature<MultiPolygon, MapObjectPolygonProperties>;
export type MapObjectCircleFeature = GeojsonFeature<Point, MapObjectCircleProperties>;
export type MapObjectLineFeature = GeojsonFeature<LineString, MapObjectLineProperties>;
export type MapObjectFeature =
	MapObjectPolygonFeature | MapObjectIconFeature | MapObjectCircleFeature | MapObjectLineFeature;

export function isFeatureIcon(feature: MapObjectFeature): feature is MapObjectIconFeature {
	return feature.properties.type === FeatureTypes.ICON;
}

export function isFeatureCircle(feature: MapObjectFeature): feature is MapObjectCircleFeature {
	return feature.properties.type === FeatureTypes.CIRCLE;
}

export function isFeaturePolygon(feature: MapObjectFeature): feature is MapObjectPolygonFeature {
	return feature.properties.type === FeatureTypes.POLYGON;
}

export function isFeatureLine(feature: MapObjectFeature): feature is MapObjectLineFeature {
	return feature.properties.type === FeatureTypes.LINE;
}

export function getIconFeature(
	id: string,
	coordinates: Point["coordinates"],
	properties: MinMapObjectIconProperties
): MapObjectIconFeature {
	let imageUrl = properties.imageUrl;
	if (!imageUrl.startsWith("data:") && imageUrl && !imageUrl.includes("w=")) {
		imageUrl = resize(imageUrl, { width: 64, normalize: properties.normalize });
	}

	// fixes some warnings about types
	const { imageOffset, ...rest } = properties;
	const hasOffset = !!imageOffset && (imageOffset[0] !== 0 || imageOffset[1] !== 0);

	return {
		type: "Feature",
		geometry: {
			type: "Point",
			coordinates
		},
		properties: {
			...rest,
			...(hasOffset ? { imageOffset } : {}),
			imageUrl,
			imageId:
				(properties.imageId ?? properties.imageUrl) + (properties.normalize ? "/normalized" : ""),
			dimmed: properties.dimmed ?? false,
			type: FeatureTypes.ICON
		},
		id
	};
}

export function getPolygonFeature(
	id: string,
	coordinates: MultiPolygon["coordinates"],
	properties: Omit<MapObjectPolygonProperties, "type" | "selectedScale">
): MapObjectPolygonFeature {
	return {
		type: "Feature",
		geometry: {
			type: "MultiPolygon",
			coordinates
		},
		properties: {
			...properties,
			type: FeatureTypes.POLYGON
		},
		id
	};
}

export function getCircleFeature(
	id: string,
	coordinates: Point["coordinates"],
	properties: Omit<MapObjectCircleProperties, "type">
): MapObjectCircleFeature {
	return {
		type: "Feature",
		geometry: {
			type: "Point",
			coordinates
		},
		properties: {
			...properties,
			type: FeatureTypes.CIRCLE
		},
		id
	};
}

export function getLineFeature(
	id: string,
	coordinates: LineString["coordinates"],
	properties: Omit<MapObjectLineProperties, "type">
): MapObjectLineFeature {
	return {
		type: "Feature",
		geometry: {
			type: "LineString",
			coordinates
		},
		properties: {
			...properties,
			type: FeatureTypes.LINE
		},
		id
	};
}
