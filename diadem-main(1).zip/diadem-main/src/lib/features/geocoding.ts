import { getMap } from "@/lib/map/map.svelte";
import { getLocale } from "@/lib/paraglide/runtime";
import { addAddressSearchResults, setIsSearchingAddress } from "@/lib/services/search.svelte";
import { getHeaders, parseResponse } from "@/lib/utils/requests";
import type { BBox, Geometry } from "geojson";

const searchDebounceMs = 100;

export type AddressData = {
	name: string;
	center: number[];
	id: string;
	bbox?: BBox;
	geometry?: Geometry;
};

let abortController: AbortController | undefined = undefined;
let debounceTimer: ReturnType<typeof setTimeout> | undefined = undefined;

export async function searchAddress(query: string, ignoreMinCharacters: boolean) {
	if (!ignoreMinCharacters && query.length <= 2) return;

	setIsSearchingAddress(true);

	const lang = getLocale();

	if (debounceTimer) clearTimeout(debounceTimer);

	let data: AddressData[] = [];

	debounceTimer = setTimeout(async () => {
		if (abortController) abortController.abort();
		abortController = new AbortController();

		let lat = "";
		let lon = "";
		const center = getMap()?.getCenter();
		if (center) {
			// 1 decimal is enough precision for address search, allows results to be cached
			lat = center.lat.toFixed(1);
			lon = center.lng.toFixed(1);
		}

		let url = "/api/search/address/" + encodeURIComponent(query) + "?lang=" + lang;
		if (lat && lon) {
			url += `&lat=${lat}&lon=${lon}`;
		}

		try {
			const result = await fetch(url, {
				headers: getHeaders(),
				signal: abortController.signal
			});

			if (!result.ok) {
				console.error("Address request failed!");
				return;
			}

			data = await parseResponse<AddressData[]>(result);
			addAddressSearchResults(data, query);
		} catch (error: any) {
			if (error.name !== "AbortError") {
				console.error("Error while searching for address", error);
			}
		}
	}, searchDebounceMs);
}
