import type { AnyFilter, FilterNest, FilterPokemon } from "@/lib/features/filters/filters";
import type {
	FiltersetContest,
	FiltersetInvasion,
	FiltersetLure,
	FiltersetMaxBattle,
	FiltersetNest,
	FiltersetQuest,
	FiltersetRaid
} from "@/lib/features/filters/filtersets";
import { deleteAllFeatures } from "@/lib/map/featuresGen.svelte";
import { MapObjectType } from "@/lib/mapObjects/mapObjectTypes";
import { updateAllMapObjects } from "@/lib/mapObjects/updateMapObject";
import { defaultFilter } from "@/lib/services/userSettings.svelte";
import type { ContestFocus, QuestReward } from "@/lib/types/mapObjectData/pokestop";
import { getDefaultGymFilter } from "@/lib/utils/gymUtils";
import { getDefaultPokestopFilter, RewardType } from "@/lib/utils/pokestopUtils";
import { getDefaultStationFilter } from "@/lib/utils/stationUtils";
import {
	closeOverlay,
	isReconcilingOverlays,
	openOverlay,
	registerOverlayHandler
} from "@/lib/ui/overlays.svelte";
import { m } from "@/lib/paraglide/messages";
import { mPokemon } from "$lib/services/ingameLocale";

export type ActiveSearchParams = {
	filter: AnyFilter;
	mapObject: MapObjectType;
	name: string;
};

let activeSearchSvelte: ActiveSearchParams | undefined = $state(undefined);

registerOverlayHandler("active-search", (entries) => {
	if (entries.length === 0 && activeSearchSvelte) resetActiveSearchFilter();
});

export function getActiveSearch() {
	return activeSearchSvelte;
}

export function isSearchViewActive() {
	return Boolean(activeSearchSvelte);
}

export function setActiveSearch(newParams: ActiveSearchParams) {
	activeSearchSvelte = newParams;
	deleteAllFeatures();
	updateAllMapObjects().then();
	if (!isReconcilingOverlays()) openOverlay({ kind: "active-search", id: "banner" });
}

export function clearActiveSearchFilter() {
	activeSearchSvelte = undefined;
	deleteAllFeatures();
	if (!isReconcilingOverlays()) closeOverlay({ kind: "active-search", id: "banner" });
}

export function resetActiveSearchFilter() {
	clearActiveSearchFilter();
	updateAllMapObjects().then();
}

export function setActiveSearchPokemon(pokemon: { pokemon_id: number; form?: number }) {
	setActiveSearch({
		name: mPokemon(pokemon),
		mapObject: MapObjectType.POKEMON,
		filter: {
			category: "pokemon",
			enabled: true,
			filters: [
				{
					id: "searchOverwrite",
					enabled: true,
					title: { message: "unknown_filter" },
					icon: { isUserSelected: false },
					pokemon: [
						{
							pokemon_id: pokemon.pokemon_id,
							form: pokemon.form
						}
					]
				}
			]
		} as FilterPokemon
	});
}

export function setActiveSearchQuest(name: string, reward: QuestReward) {
	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		rewardType: reward.type
	} as FiltersetQuest;

	switch (reward.type) {
		case RewardType.ITEM:
			filterset.item = [{ id: reward.info.item_id.toString() }];
			break;
		case RewardType.CANDY:
			filterset.candy = [{ id: reward.info.pokemon_id.toString() }];
			break;
		case RewardType.POKEMON:
			filterset.pokemon = [reward.info];
			break;
		case RewardType.XL_CANDY:
			filterset.xlCandy = [{ id: reward.info.pokemon_id.toString() }];
			break;
		case RewardType.MEGA_ENERGY:
		case RewardType.TEMP_EVO_BRANCH_RESOURCE:
			filterset.megaResource = [{ id: String(reward.info.pokemon_id) }];
			break;
		case RewardType.XP:
			filterset.xp = { min: 0, max: Infinity };
			break;
		case RewardType.STARDUST:
			filterset.stardust = { min: 0, max: Infinity };
			break;
		case RewardType.POKECOINS:
			filterset.pokecoins = { min: 0, max: Infinity };
			break;
	}

	const filter = getDefaultPokestopFilter();
	filter.quest.enabled = true;
	filter.quest.filters = [filterset];
	filter.enabled = true;

	setActiveSearch({
		name,
		mapObject: MapObjectType.POKESTOP,
		filter: filter
	});
}

export function setActiveSearchKecleon() {
	const filter = getDefaultPokestopFilter();
	filter.kecleon.enabled = true;
	filter.enabled = true;

	setActiveSearch({
		name: m.kecleon_pokestops(),
		mapObject: MapObjectType.POKESTOP,
		filter: filter
	});
}

export function setActiveSearchContest(name: string, rankingStandard: number, focus: ContestFocus) {
	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		rankingStandard,
		focus
	} as FiltersetContest;

	const filter = getDefaultPokestopFilter();
	filter.contest.enabled = true;
	filter.contest.filters = [filterset];
	filter.enabled = true;

	setActiveSearch({
		name,
		mapObject: MapObjectType.POKESTOP,
		filter: filter
	});
}

export function setActiveSearchLure(name: string, itemId: number) {
	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		items: [itemId]
	} as FiltersetLure;

	const filter = getDefaultPokestopFilter();
	filter.lure.enabled = true;
	filter.lure.filters = [filterset];
	filter.enabled = true;

	setActiveSearch({
		name,
		mapObject: MapObjectType.POKESTOP,
		filter: filter
	});
}

export function setActiveSearchInvasion(name: string, characterId: number) {
	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		characters: [characterId]
	} as FiltersetInvasion;

	const filter = getDefaultPokestopFilter();
	filter.invasion.enabled = true;
	filter.invasion.filters = [filterset];
	filter.enabled = true;

	setActiveSearch({
		name,
		mapObject: MapObjectType.POKESTOP,
		filter: filter
	});
}

export function setActiveSearchRaidBoss(
	name: string,
	pokemonId: number,
	formId: number | undefined,
	tempEvoId: number | undefined
) {
	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		bosses: [
			{
				pokemon_id: pokemonId
			}
		]
	} as FiltersetRaid;

	if (formId && filterset.bosses) filterset.bosses[0].form = formId;
	if (tempEvoId && filterset.bosses) filterset.bosses[0].temp_evolution_id = tempEvoId;

	const filter = getDefaultGymFilter();
	filter.gymPlain.enabled = false;
	filter.raid.enabled = true;
	filter.raid.filters = [filterset];
	filter.enabled = true;

	setActiveSearch({
		name,
		mapObject: MapObjectType.GYM,
		filter: filter
	});
}

export function setActiveSearchRaidLevel(name: string, level: number) {
	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		levels: [level]
	} as FiltersetRaid;

	const filter = getDefaultGymFilter();
	filter.gymPlain.enabled = false;
	filter.raid.enabled = true;
	filter.raid.filters = [filterset];
	filter.enabled = true;

	setActiveSearch({
		name,
		mapObject: MapObjectType.GYM,
		filter: filter
	});
}

export function setActiveSearchMaxBattleBoss(
	name: string,
	pokemon_id: number,
	form: number,
	bread_mode: number
) {
	const pokemon = { pokemon_id, form, bread_mode };

	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		bosses: [pokemon]
	} as FiltersetMaxBattle;

	const filter = getDefaultStationFilter();
	filter.maxBattle.enabled = true;
	filter.maxBattle.filters = [filterset];
	filter.enabled = true;

	setActiveSearch({
		name,
		mapObject: MapObjectType.STATION,
		filter: filter
	});
}

export function setActiveSearchNest(pokemon_id: number, form: number) {
	const filter = { category: "nest", ...defaultFilter(true) } as FilterNest;

	const pokemon = { pokemon_id, form };

	const filterset = {
		id: "searchOverwrite",
		enabled: true,
		title: { message: "unknown_filter" },
		icon: { isUserSelected: false },
		pokemon: [pokemon]
	} as FiltersetNest;

	filter.filters.push(filterset);

	setActiveSearch({
		name: m.pokemon_nests({ pokemon: mPokemon({ pokemon_id, form }) }),
		mapObject: MapObjectType.NEST,
		filter: filter
	});
}
