import { getMap } from "@/lib/map/map.svelte";
import { openPopup } from "@/lib/mapObjects/interact";
import { addMapObjects } from "@/lib/mapObjects/mapObjectsState.svelte";
import { type QueryableMapData, MapObjectType } from "@/lib/mapObjects/mapObjectTypes";
import * as m from "@/lib/paraglide/messages";
import { getUserSettings, updateMapPosition } from "@/lib/services/userSettings.svelte";
import { openToast } from "@/lib/ui/toasts.svelte";
import { mAny } from "@/lib/utils/anyMessage";
import { Coords } from "@/lib/utils/coordinates";
import { type KojiFeature } from "@/lib/features/koji";
import { getHeaders, parseResponse } from "@/lib/utils/requests";

export type DirectLinkData =
	QueryableMapData | { type: MapObjectType; noPermission?: boolean; id?: undefined };

let directLinkObject: DirectLinkData | undefined = $state(undefined);
let directLinkFeature: KojiFeature | undefined = $state(undefined);

export function getDirectLinkObject() {
	return directLinkObject;
}

export function setDirectLinkObject(data: DirectLinkData) {
	directLinkObject = data;
}

export function setDirectLinkFeature(feature: KojiFeature) {
	directLinkFeature = feature;
}

export function getDirectLinkFeature() {
	return directLinkFeature;
}

export function openMapObject(data: QueryableMapData, alwaysFly: boolean = false) {
	openPopup(data, true);
	addMapObjects([data], data.type, 1);

	const map = getMap();
	if (!map) return;

	if (alwaysFly || !map.getBounds().contains(Coords.infer(data).maplibre())) {
		getUserSettings().mapPosition.center.lat = data.lat;
		getUserSettings().mapPosition.center.lng = data.lon;
		getUserSettings().mapPosition.zoom = 18;
		updateMapPosition();

		map.setCenter({ lat: data.lat, lng: data.lon });
		map.setZoom(17);
	}
}

export async function openMapObjectFromId(type: MapObjectType, id: string) {
	const response = await fetch("/api/" + type + "/" + id, { headers: getHeaders() });
	if (!response.ok) {
		openToast(
			m.direct_link_not_found({
				type: mAny("pogo_" + type)
			}),
			1000
		);
		return;
	}
	const data = await parseResponse<QueryableMapData>(response);
	openMapObject(data, true);
}
