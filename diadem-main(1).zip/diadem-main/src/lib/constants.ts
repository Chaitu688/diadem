/**
 * Max Zoom level to still update the map while idling
 */
export const UPDATE_MAP_OBJECT_INTERVAL_MAX_ZOOM = 5;

/**
 * Time to wait between idle map updates (ms)
 */
export const UPDATE_MAP_OBJECT_INTERVAL_TIME = 5000;

/**
 * Time to wait between map updates when aggressive map updates are enabled (ms)
 */
export const AGGRESSIVE_UPDATE_TIME = 200;

/**
 * A fort is considered outdated if not updated within this timeframe (seconds)
 */
export const FORT_OUTDATED_SECONDS = 24 * 60 * 60;

/**
 * Weather is considered outdated if not updated within this timeframe (seconds)
 */
export const WEATHER_OUTDATED_SECONDS = 60 * 60 * 6;

/**
 * A spawnpoint is considered outdated if not updated within this timeframe (seconds)
 */
export const SPAWNPOINT_OUTDATED_SECONDS = 60 * 60 * 24; // 1 day

/**
 * Always show PVP ranks > X in Pokemon Popups
 */
export const POKEMON_MIN_RANK = 15;

/**
 * How much to increase the map icon's size when it's selected
 */
export const SELECTED_MAP_OBJECT_SCALE = 2;

/**
 * Interval to update a user's permissions (i.e. what roles they have) (seconds)
 */
export const PERMISSION_UPDATE_INTERVAL = 5 * 60;

/**
 * How long to keep a shiny rate for a pokemon (in seconds)
 */
export const SHINY_RATE_CACHE_DURATION = 60 * 60;

/**
 * The radius in which a bot can see wild pokemon, in meters
 */
export const RADIUS_POKEMON = 70;

/**
 * Player facing ranges
 */
export const RANGE_POKEMON = 40;
export const RANGE_POKEMON_EXTENDED = 80;
export const RANGE_FORTS = 80;

/**
 * The radius in which scout mode requests cells, in meters
 */
export const RADIUS_SCOUT_GMO = 1000;

export const REFRESH_MASTERFILE = 60 * 60;
export const REFRESH_REMOTE_LOCALE = 3 * 60 * 60;
export const REFRESH_UICON_INDEX = 12 * 60 * 60;
export const REFRESH_MASTER_STATS = 60 * 60;
