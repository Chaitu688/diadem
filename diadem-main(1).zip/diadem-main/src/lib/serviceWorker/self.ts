export const self = globalThis.self as unknown as ServiceWorkerGlobalScope;
