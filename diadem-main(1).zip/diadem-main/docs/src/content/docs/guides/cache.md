---
title: Caching
---

Diadem proxies all external resources through its own server, so your users don't have to directly hit external links,
and so it can optimize the resources.

Some of these resources are set up to be cached by clients by default, but it's recommended 
to set up your own Caching layer, to act as a CDN.

## UIcons

Diadem serves your configured UIcons on `/assets/{id}`. Icons are optimized, converted to WebP, and optionally scaled
to width 64. It sets caching headers, so clients will cache the icons locally.

- `/assets/home/pokemon/25.png?w=64` returns the HOME icon for Pikachu, scaled to width 64 (cached by clients for 120 days)
- `/assets/home/index.json` serves the UIcon index for the HOME icon set

## Public resources

Diadem sends cache headers for these public, slow-changing resources. Cloudflare can use the origin policy directly or
apply matching Edge TTL rules.

| Resource | Browser TTL | Edge TTL |
| --- | --- | --- |
| `/api/config` | 5 minutes | 1 hour |
| `/api/pogodata` | 1 hour | 1 hour |
| `/api/stats` | 5 minutes | 1 hour |
| `/api/koji` | 1 minute | 5 minutes |
| `/api/locale/*` | 1 hour | 3 hours |
| `/assets/*/index.json` | 5 minutes | 12 hours |

## Set up Cloudflare Cache Rules

These are a lot of resources that rarely change, so setting up a CDN for them makes a lot of sense. For the UIcon
endpoints, it's almost essential for a well-running map.

This is how you can proxy your UIcon images through Cloudflare's CDN.
This assumes you're already proxying Diadem through Cloudflare.

1. From your site dashboard navigate to Caching → Cache Rules
2. Create a rule
   ![URI Full / wildcard / https://*.example.com/assets/* And URI Path / does not end ... / index.json](../../../assets/cloudflare-cache.png)
3. You can now configure how long you want the images to last on Cloudflare's server (Edge TTL) and how long in your
   user's browsers (Browser TTL)

You can set up similar rules for icon set indexes and the public resources listed above. Use an explicit allowlist;
do not use a blanket Cache Everything rule for `/api/*`.

